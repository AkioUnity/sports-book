<?php

App::uses('AppHelper', 'View/Helper');

class UserHelper extends AppHelper
{
    /**
     * Helper name
     *
     * @var string
     */
    public $name = 'User';
}